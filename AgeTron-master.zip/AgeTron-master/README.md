Agetron integration/staging tree
================================

http://www.agetron.com

Copyright (c) 2009-2013 Bitcoin Developers

Copyright (c) 2017-2018 Agetron Developers

What is Agetron?
----------------

Agetron is an experimental new digital currency that enables instant payments to
anyone, anywhere in the world. Agetron uses peer-to-peer technology to operate
with no central authority: managing transactions and issuing money are carried
out collectively by the network. Agetron is also the name of the open source
software which enables the use of this currency.

For more information, as well as an immediately useable, binary version of
the Agetron client software, see http://www.agetron.com

License
-------

Agetron is released under the terms of the MIT license. See `COPYING` for more
information or see http://opensource.org/licenses/MIT.

