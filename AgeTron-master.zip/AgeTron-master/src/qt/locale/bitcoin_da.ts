<?xml version="1.0" ?><!DOCTYPE TS><TS language="da" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="+14"/>
        <source>About Agetron</source>
        <translation>Om Agetron</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>&lt;b&gt;Agetron&lt;/b&gt; version</source>
        <translation>&lt;b&gt;Agetron&lt;/b&gt; version</translation>
    </message>
    <message>
        <location line="+57"/>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>
Dette program er ekperimentielt.

Det er gjort tilgængeligt under MIT/X11-softwarelicensen. Se den tilhørende fil &quot;COPYING&quot; eller http://www.opensource.org/licenses/mit-license.php.

Produktet indeholder software som er udviklet af OpenSSL Project til brug i OpenSSL Toolkit (http://www.openssl.org/), kryptografisk software skrevet af Eric Young (eay@cryptsoft.com) og UPnP-software skrevet af Thomas Bernard.</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="+14"/>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The Agetron developers</source>
        <translation>Agetron-udviklerne</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="+14"/>
        <source>Address Book</source>
        <translation>Adressebog</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Double-click to edit address or label</source>
        <translation>Dobbeltklik for at redigere adresse eller mærkat</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Create a new address</source>
        <translation>Opret en ny adresse</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopier den valgte adresse til systemets udklipsholder</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>&amp;New Address</source>
        <translation>Ny adresse</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="+63"/>
        <source>These are your Agetron addresses for receiving payments. You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation>Dette er dine Agetron-adresser til at modtage betalinger med. Du kan give en forskellig adresse til hver afsender, så du kan holde styr på, hvem der betaler dig.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="+14"/>
        <source>&amp;Copy Address</source>
        <translation>Kopier adresse</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Show &amp;QR Code</source>
        <translation>Vis QR-kode</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Sign a message to prove you own a Agetron address</source>
        <translation>Underskriv en besked for at bevise, at en Agetron-adresse tilhører dig</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sign &amp;Message</source>
        <translation>Underskriv besked</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Delete the currently selected address from the list</source>
        <translation>Slet den markerede adresse fra listen</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportér den aktuelle visning til en fil</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Export</source>
        <translation>Eksporter</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Verify a message to ensure it was signed with a specified Agetron address</source>
        <translation>Efterprøv en besked for at sikre, at den er underskrevet med den angivne Agetron-adresse</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Verify Message</source>
        <translation>Efterprøv besked</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Delete</source>
        <translation>Slet</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="-5"/>
        <source>These are your Agetron addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Disse er dine Agetron-adresser for at sende betalinger. Tjek altid beløb og modtageradresse, inden du sender Agetron.</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Copy &amp;Label</source>
        <translation>Kopier mærkat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Send &amp;Coins</source>
        <translation>Send Agetron</translation>
    </message>
    <message>
        <location line="+260"/>
        <source>Export Address Book Data</source>
        <translation>Eksporter adressebogsdata</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommasepareret fil (*.csv)</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Error exporting</source>
        <translation>Fejl under eksport</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>Kunne ikke skrive til filen %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="+144"/>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="+26"/>
        <source>Passphrase Dialog</source>
        <translation>Adgangskodedialog</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Enter passphrase</source>
        <translation>Indtast adgangskode</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>New passphrase</source>
        <translation>Ny adgangskode</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Repeat new passphrase</source>
        <translation>Gentag ny adgangskode</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="+33"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Indtast den nye adgangskode til tegnebogen.&lt;br/&gt;Brug venligst en adgangskode på &lt;b&gt;10 eller flere tilfældige tegn&lt;/b&gt; eller &lt;b&gt;otte eller flere ord&lt;/b&gt;.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Encrypt wallet</source>
        <translation>Krypter tegnebog</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Denne funktion har brug for din tegnebogs adgangskode for at låse tegnebogen op.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Unlock wallet</source>
        <translation>Lås tegnebog op</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Denne funktion har brug for din tegnebogs adgangskode for at dekryptere tegnebogen.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Decrypt wallet</source>
        <translation>Dekrypter tegnebog</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Change passphrase</source>
        <translation>Skift adgangskode</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Indtast den gamle og den nye adgangskode til tegnebogen.</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Confirm wallet encryption</source>
        <translation>Bekræft tegnebogskryptering</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!</source>
        <translation>Advarsel: Hvis du krypterer din tegnebog og mister din adgangskode, vil du &lt;b&gt;MISTE ALLE DINE BITCOINS&lt;/b&gt;!</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Er du sikker på, at du ønsker at kryptere din tegnebog?</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>VIGTIGT: Enhver tidligere sikkerhedskopi, som du har lavet af tegnebogsfilen, bør blive erstattet af den nyligt genererede, krypterede tegnebogsfil. Af sikkerhedsmæssige årsager vil tidligere sikkerhedskopier af den ikke-krypterede tegnebogsfil blive ubrugelig i det øjeblik, du starter med at anvende den nye, krypterede tegnebog.</translation>
    </message>
    <message>
        <location line="+100"/>
        <location line="+24"/>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Advarsel: Caps Lock-tasten er aktiveret!</translation>
    </message>
    <message>
        <location line="-130"/>
        <location line="+58"/>
        <source>Wallet encrypted</source>
        <translation>Tegnebog krypteret</translation>
    </message>
    <message>
        <location line="-56"/>
        <source>Agetron will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your Agetron from being stolen by malware infecting your computer.</source>
        <translation>Agetron vil nu lukke for at gennemføre krypteringsprocessen. Husk på, at kryptering af din tegnebog vil ikke beskytte dine Agetron fuldt ud mod at blive stjålet af malware på din computer.</translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+7"/>
        <location line="+42"/>
        <location line="+6"/>
        <source>Wallet encryption failed</source>
        <translation>Tegnebogskryptering mislykkedes</translation>
    </message>
    <message>
        <location line="-54"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Tegnebogskryptering mislykkedes på grund af en intern fejl. Din tegnebog blev ikke krypteret.</translation>
    </message>
    <message>
        <location line="+7"/>
        <location line="+48"/>
        <source>The supplied passphrases do not match.</source>
        <translation>De angivne adgangskoder stemmer ikke overens.</translation>
    </message>
    <message>
        <location line="-37"/>
        <source>Wallet unlock failed</source>
        <translation>Tegnebogsoplåsning mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+11"/>
        <location line="+19"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Den angivne adgangskode for tegnebogsdekrypteringen er forkert.</translation>
    </message>
    <message>
        <location line="-20"/>
        <source>Wallet decryption failed</source>
        <translation>Tegnebogsdekryptering mislykkedes</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Tegnebogens adgangskode blev ændret.</translation>
    </message>
</context>
<context>
    <name>AgetronGUI</name>
    <message>
        <location filename="../Agetrongui.cpp" line="+233"/>
        <source>Sign &amp;message...</source>
        <translation>Underskriv besked...</translation>
    </message>
    <message>
        <location line="+280"/>
        <source>Synchronizing with network...</source>
        <translation>Synkroniserer med netværk...</translation>
    </message>
    <message>
        <location line="-349"/>
        <source>&amp;Overview</source>
        <translation>Oversigt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show general overview of wallet</source>
        <translation>Vis generel oversigt over tegnebog</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>&amp;Transactions</source>
        <translation>Transaktioner</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Browse transaction history</source>
        <translation>Gennemse transaktionshistorik</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Rediger listen over gemte adresser og mærkater</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Vis listen over adresser for at modtage betalinger</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>E&amp;xit</source>
        <translation>Luk</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Quit application</source>
        <translation>Afslut program</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Show information about Agetron</source>
        <translation>Vis informationer om Agetron</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>About &amp;Qt</source>
        <translation>Om Qt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show information about Qt</source>
        <translation>Vis informationer om Qt</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Options...</source>
        <translation>Indstillinger...</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Krypter tegnebog...</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Backup Wallet...</source>
        <translation>Sikkerhedskopier tegnebog...</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Change Passphrase...</source>
        <translation>Skift adgangskode...</translation>
    </message>
    <message>
        <location line="+285"/>
        <source>Importing blocks from disk...</source>
        <translation>Importerer blokke fra disken...</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Reindexing blocks on disk...</source>
        <translation>Genindekserer blokke på disken...</translation>
    </message>
    <message>
        <location line="-347"/>
        <source>Send coins to a Agetron address</source>
        <translation>Send Agetron til en Agetron-adresse</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Modify configuration options for Agetron</source>
        <translation>Rediger konfigurationsindstillinger af Agetron</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Backup wallet to another location</source>
        <translation>Lav sikkerhedskopi af tegnebogen til et andet sted</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Skift adgangskode anvendt til tegnebogskryptering</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Debug window</source>
        <translation>Fejlsøgningsvindue</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Open debugging and diagnostic console</source>
        <translation>Åbn fejlsøgnings- og diagnosticeringskonsollen</translation>
    </message>
    <message>
        <location line="-4"/>
        <source>&amp;Verify message...</source>
        <translation>Efterprøv besked...</translation>
    </message>
    <message>
        <location line="-165"/>
        <location line="+530"/>
        <source>Agetron</source>
        <translation>Agetron</translation>
    </message>
    <message>
        <location line="-530"/>
        <source>Wallet</source>
        <translation>Tegnebog</translation>
    </message>
    <message>
        <location line="+101"/>
        <source>&amp;Send</source>
        <translation>Send</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Receive</source>
        <translation>Modtag</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Addresses</source>
        <translation>Adresser</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>&amp;About Agetron</source>
        <translation>Om Agetron</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Show / Hide</source>
        <translation>Vis/skjul</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show or hide the main Window</source>
        <translation>Vis eller skjul hovedvinduet</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Krypter de private nøgler, der hører til din tegnebog</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Sign messages with your Agetron addresses to prove you own them</source>
        <translation>Underskriv beskeder med dine Agetron-adresser for at bevise, at de tilhører dig</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Verify messages to ensure they were signed with specified Agetron addresses</source>
        <translation>Efterprøv beskeder for at sikre, at de er underskrevet med de(n) angivne Agetron-adresse(r)</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>&amp;File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Settings</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Help</source>
        <translation>Hjælp</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Tabs toolbar</source>
        <translation>Faneværktøjslinje</translation>
    </message>
    <message>
        <location line="+17"/>
        <location line="+10"/>
        <source>[testnet]</source>
        <translation>[testnetværk]</translation>
    </message>
    <message>
        <location line="+47"/>
        <source>Agetron client</source>
        <translation>Agetron-klient</translation>
    </message>
    <message numerus="yes">
        <location line="+141"/>
        <source>%n active connection(s) to Agetron network</source>
        <translation><numerusform>%n aktiv(e) forbindelse(r) til Agetron-netværket</numerusform><numerusform>%n aktiv(e) forbindelse(r) til Agetron-netværket</numerusform></translation>
    </message>
    <message>
        <location line="+22"/>
        <source>No block source available...</source>
        <translation>Ingen blokkilde tilgængelig...</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Processed %1 of %2 (estimated) blocks of transaction history.</source>
        <translation>%1 ud af %2 (estimeret) blokke af transaktionshistorikken er blevet behandlet.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Processed %1 blocks of transaction history.</source>
        <translation>%1 blokke af transaktionshistorikken er blevet behandlet.</translation>
    </message>
    <message numerus="yes">
        <location line="+20"/>
        <source>%n hour(s)</source>
        <translation><numerusform>%n time(r)</numerusform><numerusform>%n time(r)</numerusform></translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n day(s)</source>
        <translation><numerusform>%n dag(e)</numerusform><numerusform>%n dag(e)</numerusform></translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n week(s)</source>
        <translation><numerusform>%n uge(r)</numerusform><numerusform>%n uge(r)</numerusform></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>%1 behind</source>
        <translation>%1 bagefter</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Last received block was generated %1 ago.</source>
        <translation>Senest modtagne blok blev genereret for %1 siden.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transaktioner herefter vil endnu ikke være synlige.</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location line="+70"/>
        <source>This transaction is over the size limit. You can still send it for a fee of %1, which goes to the nodes that process your transaction and helps to support the network. Do you want to pay the fee?</source>
        <translation>Transaktionen overskrider størrelsesgrænsen. Du kan stadig sende den for et gebyr på %1, hvilket går til de knuder, der behandler din transaktion og hjælper med at understøtte netværket. Vil du betale gebyret?</translation>
    </message>
    <message>
        <location line="-140"/>
        <source>Up to date</source>
        <translation>Opdateret</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Catching up...</source>
        <translation>Indhenter...</translation>
    </message>
    <message>
        <location line="+113"/>
        <source>Confirm transaction fee</source>
        <translation>Bekræft transaktionsgebyr</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Sent transaction</source>
        <translation>Afsendt transaktion</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Incoming transaction</source>
        <translation>Indgående transaktion</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Dato: %1
Beløb: %2
Type: %3
Adresse: %4
</translation>
    </message>
    <message>
        <location line="+33"/>
        <location line="+23"/>
        <source>URI handling</source>
        <translation>URI-håndtering</translation>
    </message>
    <message>
        <location line="-23"/>
        <location line="+23"/>
        <source>URI can not be parsed! This can be caused by an invalid Agetron address or malformed URI parameters.</source>
        <translation>URI kan ikke fortolkes! Dette kan skyldes en ugyldig Agetron-adresse eller misdannede URI-parametre.</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Tegnebog er &lt;b&gt;krypteret&lt;/b&gt; og i øjeblikket &lt;b&gt;ulåst&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Tegnebog er &lt;b&gt;krypteret&lt;/b&gt; og i øjeblikket &lt;b&gt;låst&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../Agetron.cpp" line="+111"/>
        <source>A fatal error occurred. Agetron can no longer continue safely and will quit.</source>
        <translation>Der opstod en fatal fejl. Agetron kan ikke længere fortsætte sikkert og vil afslutte.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <location filename="../clientmodel.cpp" line="+104"/>
        <source>Network Alert</source>
        <translation>Netværksadvarsel</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="+14"/>
        <source>Edit Address</source>
        <translation>Rediger adresse</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The label associated with this address book entry</source>
        <translation>Mærkaten forbundet med denne post i adressebogen</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Adressen tilknyttet til denne post i adressebogen. Dette kan kun ændres for afsendelsesadresser.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="+21"/>
        <source>New receiving address</source>
        <translation>Ny modtagelsesadresse</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>New sending address</source>
        <translation>Ny afsendelsesadresse</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Edit receiving address</source>
        <translation>Rediger modtagelsesadresse</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Edit sending address</source>
        <translation>Rediger afsendelsesadresse</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Den indtastede adresse &quot;%1&quot; er allerede i adressebogen.</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>The entered address &quot;%1&quot; is not a valid Agetron address.</source>
        <translation>Den indtastede adresse &quot;%1&quot; er ikke en gyldig Agetron-adresse.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Could not unlock wallet.</source>
        <translation>Kunne ikke låse tegnebog op.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>New key generation failed.</source>
        <translation>Ny nøglegenerering mislykkedes.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    <message>
        <location filename="../guiutil.cpp" line="+424"/>
        <location line="+12"/>
        <source>Agetron-Qt</source>
        <translation>Agetron-Qt</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>version</source>
        <translation>version</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Usage:</source>
        <translation>Anvendelse:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>command-line options</source>
        <translation>kommandolinjetilvalg</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>UI options</source>
        <translation>Brugergrænsefladeindstillinger</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Angiv sprog, f.eks &quot;de_DE&quot; (standard: systemlokalitet)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Start minimized</source>
        <translation>Start minimeret</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Vis opstartsbillede ved start (standard: 1)</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../forms/optionsdialog.ui" line="+14"/>
        <source>Options</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>&amp;Main</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB.</source>
        <translation>Valgfrit transaktionsgebyr pr. kB, der hjælper dine transaktioner med at blive behandlet hurtigt. De fleste transaktioner er på 1 kB.</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Pay transaction &amp;fee</source>
        <translation>Betal transaktionsgebyr</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Automatically start Agetron after logging in to the system.</source>
        <translation>Start Agetron automatisk, når der logges ind på systemet</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Start Agetron on system login</source>
        <translation>Start Agetron, når systemet startes</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>Reset all client options to default.</source>
        <translation>Nulstil alle klientindstillinger til deres standard.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Reset Options</source>
        <translation>Nulstil indstillinger</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>&amp;Network</source>
        <translation>Netværk</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Automatically open the Agetron client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Åbn Agetron-klientens port på routeren automatisk. Dette virker kun, når din router understøtter UPnP og UPnP er aktiveret.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Konfigurer port vha. UPnP</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Connect to the Agetron network through a SOCKS proxy (e.g. when connecting through Tor).</source>
        <translation>Opret forbindelse til Agetron-netværket via en SOCKS-proxy (f.eks. ved tilslutning gennem Tor)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Connect through SOCKS proxy:</source>
        <translation>Forbind gennem SOCKS-proxy:</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy-IP:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>IP-adressen på proxyen (f.eks. 127.0.0.1)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Porten på proxyen (f.eks. 9050)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>SOCKS &amp;Version:</source>
        <translation>SOCKS-version</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>SOCKS-version af proxyen (f.eks. 5)</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>&amp;Window</source>
        <translation>Vindue</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Vis kun et statusikon efter minimering af vinduet.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>Minimer til statusfeltet i stedet for proceslinjen</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimer i stedet for at afslutte programmet, når vinduet lukkes. Når denne indstilling er valgt, vil programmet kun blive lukket, når du har valgt Afslut i menuen.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>M&amp;inimize on close</source>
        <translation>Minimer ved lukning</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Display</source>
        <translation>Visning</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>User Interface &amp;language:</source>
        <translation>Brugergrænsefladesprog:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>The user interface language can be set here. This setting will take effect after restarting Agetron.</source>
        <translation>Brugergrænsefladesproget kan angives her. Denne indstilling træder først i kraft, når Agetron genstartes.</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Unit to show amounts in:</source>
        <translation>Enhed at vise beløb i:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Vælg den standard underopdelingsenhed, som skal vises i brugergrænsefladen og ved afsendelse af Agetron.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Whether to show Agetron addresses in the transaction list or not.</source>
        <translation>Afgør hvorvidt Agetron-adresser skal vises i transaktionslisten eller ej.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Display addresses in transaction list</source>
        <translation>Vis adresser i transaktionsliste</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>&amp;Apply</source>
        <translation>Anvend</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="+53"/>
        <source>default</source>
        <translation>standard</translation>
    </message>
    <message>
        <location line="+130"/>
        <source>Confirm options reset</source>
        <translation>Bekræft nulstilling af indstillinger</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Some settings may require a client restart to take effect.</source>
        <translation>Nogle indstillinger kan kræve, at klienten genstartes, før de træder i kraft.</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Do you want to proceed?</source>
        <translation>Ønsker du at fortsætte?</translation>
    </message>
    <message>
        <location line="+42"/>
        <location line="+9"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location line="-9"/>
        <location line="+9"/>
        <source>This setting will take effect after restarting Agetron.</source>
        <translation>Denne indstilling træder i kraft, efter Agetron genstartes.</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>The supplied proxy address is invalid.</source>
        <translation>Ugyldig proxy-adresse</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="+14"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location line="+50"/>
        <location line="+166"/>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Agetron network after a connection is established, but this process has not completed yet.</source>
        <translation>Den viste information kan være forældet. Din tegnebog synkroniserer automatisk med Agetron-netværket, når en forbindelse etableres, men denne proces er ikke gennemført endnu.</translation>
    </message>
    <message>
        <location line="-124"/>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Unconfirmed:</source>
        <translation>Ubekræftede:</translation>
    </message>
    <message>
        <location line="-78"/>
        <source>Wallet</source>
        <translation>Tegnebog</translation>
    </message>
    <message>
        <location line="+107"/>
        <source>Immature:</source>
        <translation>Umodne:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Mined balance that has not yet matured</source>
        <translation>Udvunden saldo, som endnu ikke er modnet</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Nyeste transaktioner&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="-101"/>
        <source>Your current balance</source>
        <translation>Din nuværende saldo</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Summen af transaktioner, der endnu ikke er bekræftet og endnu ikke er inkluderet i den nuværende saldo</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="+116"/>
        <location line="+1"/>
        <source>out of sync</source>
        <translation>ikke synkroniseret</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <location filename="../paymentserver.cpp" line="+107"/>
        <source>Cannot start Agetron: click-to-pay handler</source>
        <translation>Kan ikke starte Agetron: click-to-pay-håndtering</translation>
    </message>
</context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="+14"/>
        <source>QR Code Dialog</source>
        <translation>QR-kode-dialog</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>Request Payment</source>
        <translation>Anmod om betaling</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>Amount:</source>
        <translation>Beløb:</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Label:</source>
        <translation>Mærkat:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Message:</source>
        <translation>Besked:</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;Save As...</source>
        <translation>Gem som...</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="+62"/>
        <source>Error encoding URI into QR Code.</source>
        <translation>Fejl ved kodning fra URI til QR-kode</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>The entered amount is invalid, please check.</source>
        <translation>Det indtastede beløb er ugyldig, tjek venligst.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Resulterende URI var for lang; prøv at forkorte teksten til mærkaten/beskeden.</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Save QR Code</source>
        <translation>Gem QR-kode</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>PNG Images (*.png)</source>
        <translation>PNG-billeder (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <location filename="../forms/rpcconsole.ui" line="+46"/>
        <source>Client name</source>
        <translation>Klientnavn</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+23"/>
        <location line="+26"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+36"/>
        <location line="+53"/>
        <location line="+23"/>
        <location line="+23"/>
        <location filename="../rpcconsole.cpp" line="+339"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location line="-217"/>
        <source>Client version</source>
        <translation>Klientversion</translation>
    </message>
    <message>
        <location line="-45"/>
        <source>&amp;Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>Using OpenSSL version</source>
        <translation>Anvendt OpenSSL-version</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Startup time</source>
        <translation>Opstartstid</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Network</source>
        <translation>Netværk</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Number of connections</source>
        <translation>Antal forbindelser</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>On testnet</source>
        <translation>Tilsluttet testnetværk</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Block chain</source>
        <translation>Blokkæde</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Current number of blocks</source>
        <translation>Nuværende antal blokke</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Estimated total blocks</source>
        <translation>Estimeret antal blokke</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Last block time</source>
        <translation>Tidsstempel for seneste blok</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>&amp;Open</source>
        <translation>Åbn</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Command-line options</source>
        <translation>Kommandolinjetilvalg</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Show the Agetron-Qt help message to get a list with possible Agetron command-line options.</source>
        <translation>Vis Agetron-Qt-hjælpebeskeden for at få en liste over de tilgængelige Agetron-kommandolinjeindstillinger.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Show</source>
        <translation>Vis</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>&amp;Console</source>
        <translation>Konsol</translation>
    </message>
    <message>
        <location line="-260"/>
        <source>Build date</source>
        <translation>Byggedato</translation>
    </message>
    <message>
        <location line="-104"/>
        <source>Agetron - Debug window</source>
        <translation>Agetron - Fejlsøgningsvindue</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Agetron Core</source>
        <translation>Agetron Core</translation>
    </message>
    <message>
        <location line="+279"/>
        <source>Debug log file</source>
        <translation>Fejlsøgningslogfil</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Open the Agetron debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Åbn Agetron-fejlsøgningslogfilen fra det nuværende datakatalog. Dette kan tage nogle få sekunder for en store logfiler.</translation>
    </message>
    <message>
        <location line="+102"/>
        <source>Clear console</source>
        <translation>Ryd konsol</translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="-30"/>
        <source>Welcome to the Agetron RPC console.</source>
        <translation>Velkommen til Agetron RPC-konsollen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Brug op og ned-piletasterne til at navigere historikken og &lt;b&gt;Ctrl-L&lt;/b&gt; til at rydde skærmen.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Tast &lt;b&gt;help&lt;/b&gt; for en oversigt over de tilgængelige kommandoer.</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="+14"/>
        <location filename="../sendcoinsdialog.cpp" line="+124"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+6"/>
        <location line="+5"/>
        <location line="+5"/>
        <source>Send Coins</source>
        <translation>Send Agetron</translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Send to multiple recipients at once</source>
        <translation>Send til flere modtagere på en gang</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Add &amp;Recipient</source>
        <translation>Tilføj modtager</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Remove all transaction fields</source>
        <translation>Fjern alle transaktionsfelter</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Clear &amp;All</source>
        <translation>Ryd alle</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>123.456 AGT</source>
        <translation>123,456 AGT</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Confirm the send action</source>
        <translation>Bekræft afsendelsen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>S&amp;end</source>
        <translation>Afsend</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="-59"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; til %2 (%3)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirm send coins</source>
        <translation>Bekræft afsendelse af Agetron</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Are you sure you want to send %1?</source>
        <translation>Er du sikker på, at du vil sende %1?</translation>
    </message>
    <message>
        <location line="+0"/>
        <source> and </source>
        <translation> og </translation>
    </message>
    <message>
        <location line="+23"/>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Modtagerens adresse er ikke gyldig. Tjek venligst adressen igen.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Beløbet til betaling skal være større end 0.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount exceeds your balance.</source>
        <translation>Beløbet overstiger din saldo.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Totalen overstiger din saldo, når %1 transaktionsgebyr er inkluderet.</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Duplikeret adresse fundet. Du kan kun sende til hver adresse en gang pr. afsendelse.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: Transaction creation failed!</source>
        <translation>Fejl: Oprettelse af transaktionen mislykkedes!</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: The transaction was rejected. This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Fejl: Transaktionen blev afvist. Dette kan ske, hvis nogle af dine Agetron i din tegnebog allerede er brugt, som hvis du brugte en kopi af wallet.dat og dine Agetron er blevet brugt i kopien, men ikke er markeret som brugt her.</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="+14"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>A&amp;mount:</source>
        <translation>Beløb:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Pay &amp;To:</source>
        <translation>Betal til:</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>The address to send the payment to (e.g. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</source>
        <translation>Agetron-adressen som betalingen skal sendes til (f.eks. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</translation>
    </message>
    <message>
        <location line="+60"/>
        <location filename="../sendcoinsentry.cpp" line="+26"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Indtast en mærkat for denne adresse for at føje den til din adressebog</translation>
    </message>
    <message>
        <location line="-78"/>
        <source>&amp;Label:</source>
        <translation>Mærkat:</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Choose address from address book</source>
        <translation>Vælg adresse fra adressebog</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Paste address from clipboard</source>
        <translation>Indsæt adresse fra udklipsholderen</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Remove this recipient</source>
        <translation>Fjern denne modtager</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="+1"/>
        <source>Enter a Agetron address (e.g. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</source>
        <translation>Indtast en Agetron-adresse (f.eks. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="+14"/>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Underskrifter - Underskriv/efterprøv en besked</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>&amp;Sign Message</source>
        <translation>Underskriv besked</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Du kan underskrive beskeder med dine Agetron-adresser for at bevise, at de tilhører dig. Pas på ikke at underskrive noget vagt, da phisingangreb kan narre dig til at overdrage din identitet. Underskriv kun fuldt detaljerede udsagn, du er enig i.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to sign the message with (e.g. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</source>
        <translation>Agetron-adressen som beskeden skal underskrives med (f.eks. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+213"/>
        <source>Choose an address from the address book</source>
        <translation>Vælg adresse fra adressebog</translation>
    </message>
    <message>
        <location line="-203"/>
        <location line="+213"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="-203"/>
        <source>Paste address from clipboard</source>
        <translation>Indsæt adresse fra udklipsholderen</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Enter the message you want to sign here</source>
        <translation>Indtast beskeden, du ønsker at underskrive</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Signature</source>
        <translation>Underskrift</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopier den nuværende underskrift til systemets udklipsholder</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Sign the message to prove you own this Agetron address</source>
        <translation>Underskriv denne besked for at bevise, at Agetron-adressen tilhører dig</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sign &amp;Message</source>
        <translation>Underskriv besked</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Reset all sign message fields</source>
        <translation>Nulstil alle underskriv besked-indtastningsfelter</translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+146"/>
        <source>Clear &amp;All</source>
        <translation>Ryd alle</translation>
    </message>
    <message>
        <location line="-87"/>
        <source>&amp;Verify Message</source>
        <translation>Efterprøv besked</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Indtast den underskrevne adresse, beskeden (inkluder linjeskift, mellemrum mv. nøjagtigt, som de fremgår) og underskriften for at efterprøve beskeden. Vær forsigtig med ikke at lægge mere i underskriften end besked selv, så du undgår at blive narret af et man-in-the-middle-angreb.</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>The address the message was signed with (e.g. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</source>
        <translation>Agetron-adressen som beskeden er underskrevet med (f.eks. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Verify the message to ensure it was signed with the specified Agetron address</source>
        <translation>Efterprøv beskeden for at sikre, at den er underskrevet med den angivne Agetron-adresse</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Verify &amp;Message</source>
        <translation>Efterprøv besked</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Reset all verify message fields</source>
        <translation>Nulstil alle efterprøv besked-indtastningsfelter</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="+27"/>
        <location line="+3"/>
        <source>Enter a Agetron address (e.g. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</source>
        <translation>Indtast en Agetron-adresse (f.eks. Fc27qmrPnU1mAwETCwFGtzcRTJh34tMa74)</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Klik &quot;Underskriv besked&quot; for at generere underskriften</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Enter Agetron signature</source>
        <translation>Indtast Agetron-underskriften</translation>
    </message>
    <message>
        <location line="+82"/>
        <location line="+81"/>
        <source>The entered address is invalid.</source>
        <translation>Den indtastede adresse er ugyldig.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+8"/>
        <location line="+73"/>
        <location line="+8"/>
        <source>Please check the address and try again.</source>
        <translation>Tjek venligst adressen, og forsøg igen.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+81"/>
        <source>The entered address does not refer to a key.</source>
        <translation>Den indtastede adresse henviser ikke til en nøgle.</translation>
    </message>
    <message>
        <location line="-73"/>
        <source>Wallet unlock was cancelled.</source>
        <translation>Tegnebogsoplåsning annulleret.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Private key for the entered address is not available.</source>
        <translation>Den private nøgle for den indtastede adresse er ikke tilgængelig.</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Message signing failed.</source>
        <translation>Underskrivning af besked mislykkedes.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message signed.</source>
        <translation>Besked underskrevet.</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>The signature could not be decoded.</source>
        <translation>Underskriften kunne ikke afkodes.</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+13"/>
        <source>Please check the signature and try again.</source>
        <translation>Tjek venligst underskriften, og forsøg igen.</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The signature did not match the message digest.</source>
        <translation>Underskriften matcher ikke beskedens indhold.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Message verification failed.</source>
        <translation>Efterprøvelse af besked mislykkedes.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message verified.</source>
        <translation>Besked efterprøvet.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <location filename="../splashscreen.cpp" line="+22"/>
        <source>The Agetron developers</source>
        <translation>Agetron-udviklerne</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="+20"/>
        <source>Open until %1</source>
        <translation>Åben indtil %1</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>%1/offline</source>
        <translation>%1/offline</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1/unconfirmed</source>
        <translation>%1/ubekræftet</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 confirmations</source>
        <translation>%1 bekræftelser</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message numerus="yes">
        <location line="+7"/>
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, transmitteret igennem %n knude(r)</numerusform><numerusform>, transmitteret igennem %n knude(r)</numerusform></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Source</source>
        <translation>Kilde</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Generated</source>
        <translation>Genereret</translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+17"/>
        <source>From</source>
        <translation>Fra</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+22"/>
        <location line="+58"/>
        <source>To</source>
        <translation>Til</translation>
    </message>
    <message>
        <location line="-77"/>
        <location line="+2"/>
        <source>own address</source>
        <translation>egen adresse</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>label</source>
        <translation>mærkat</translation>
    </message>
    <message>
        <location line="+37"/>
        <location line="+12"/>
        <location line="+45"/>
        <location line="+17"/>
        <location line="+30"/>
        <source>Credit</source>
        <translation>Kredit</translation>
    </message>
    <message numerus="yes">
        <location line="-102"/>
        <source>matures in %n more block(s)</source>
        <translation><numerusform>modner efter yderligere %n blok(ke)</numerusform><numerusform>modner efter yderligere %n blok(ke)</numerusform></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>not accepted</source>
        <translation>ikke accepteret</translation>
    </message>
    <message>
        <location line="+44"/>
        <location line="+8"/>
        <location line="+15"/>
        <location line="+30"/>
        <source>Debit</source>
        <translation>Debet</translation>
    </message>
    <message>
        <location line="-39"/>
        <source>Transaction fee</source>
        <translation>Transaktionsgebyr</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Net amount</source>
        <translation>Nettobeløb</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Message</source>
        <translation>Besked</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Transaction ID</source>
        <translation>Transaktionens ID</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated coins must mature 120 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Genererede Agetron skal vente 120 blokke, før de kan blive brugt. Da du genererede denne blok, blev den transmitteret til netværket for at blive føjet til blokkæden. Hvis det mislykkes at komme ind i kæden, vil den skifte til &quot;ikke godkendt&quot; og ikke blive kunne bruges. Dette kan lejlighedsvis ske, hvis en anden knude genererer en blok inden for få sekunder af din.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Debug information</source>
        <translation>Fejlsøgningsinformation</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Transaction</source>
        <translation>Transaktion</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Inputs</source>
        <translation>Input</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>true</source>
        <translation>sand</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>false</source>
        <translation>falsk</translation>
    </message>
    <message>
        <location line="-209"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, er ikke blevet transmitteret endnu</translation>
    </message>
    <message numerus="yes">
        <location line="-35"/>
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Åben %n blok yderligere</numerusform><numerusform>Åben %n blokke yderligere</numerusform></translation>
    </message>
    <message>
        <location line="+70"/>
        <source>unknown</source>
        <translation>ukendt</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="+14"/>
        <source>Transaction details</source>
        <translation>Transaktionsdetaljer</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Denne rude viser en detaljeret beskrivelse af transaktionen</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="+225"/>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message numerus="yes">
        <location line="+57"/>
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Åben %n blok(ke) yderligere</numerusform><numerusform>Åben %n blok(ke) yderligere</numerusform></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Open until %1</source>
        <translation>Åben indtil %1</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Offline (%1 confirmations)</source>
        <translation>Offline (%1 bekræftelser)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Ubekræftet (%1 af %2 bekræftelser)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Bekræftet (%1 bekræftelser)</translation>
    </message>
    <message numerus="yes">
        <location line="+8"/>
        <source>Mined balance will be available when it matures in %n more block(s)</source>
        <translation><numerusform>Udvunden saldo, som vil være tilgængelig, når den modner efter yderligere %n blok(ke)</numerusform><numerusform>Udvunden saldo, som vil være tilgængelig, når den modner efter yderligere %n blok(ke)</numerusform></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Denne blok blev ikke modtaget af nogen andre knuder og vil formentlig ikke blive accepteret!</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated but not accepted</source>
        <translation>Genereret, men ikke accepteret</translation>
    </message>
    <message>
        <location line="+43"/>
        <source>Received with</source>
        <translation>Modtaget med</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Received from</source>
        <translation>Modtaget fra</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sent to</source>
        <translation>Sendt til</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Payment to yourself</source>
        <translation>Betaling til dig selv</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Mined</source>
        <translation>Udvundne</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <location line="+199"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Transaktionsstatus. Hold musen over dette felt for at vise antallet af bekræftelser.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Dato og klokkeslæt for modtagelse af transaktionen.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type of transaction.</source>
        <translation>Transaktionstype.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Destination address of transaction.</source>
        <translation>Destinationsadresse for transaktion.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Beløb fjernet eller tilføjet balance.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="+52"/>
        <location line="+16"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Today</source>
        <translation>I dag</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This week</source>
        <translation>Denne uge</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This month</source>
        <translation>Denne måned</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Last month</source>
        <translation>Sidste måned</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This year</source>
        <translation>Dette år</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Range...</source>
        <translation>Interval...</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Received with</source>
        <translation>Modtaget med</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Sent to</source>
        <translation>Sendt til</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>To yourself</source>
        <translation>Til dig selv</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Mined</source>
        <translation>Udvundne</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Other</source>
        <translation>Andet</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Enter address or label to search</source>
        <translation>Indtast adresse eller mærkat for at søge</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Min amount</source>
        <translation>Minimumsbeløb</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Copy address</source>
        <translation>Kopier adresse</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy label</source>
        <translation>Kopier mærkat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy amount</source>
        <translation>Kopier beløb</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy transaction ID</source>
        <translation>Kopier transaktionens ID</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit label</source>
        <translation>Rediger mærkat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show transaction details</source>
        <translation>Vis transaktionsdetaljer</translation>
    </message>
    <message>
        <location line="+139"/>
        <source>Export Transaction Data</source>
        <translation>Eksporter transaktionsdata</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommasepareret fil (*.csv)</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Confirmed</source>
        <translation>Bekræftet</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error exporting</source>
        <translation>Fejl under eksport</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>Kunne ikke skrive til filen %1.</translation>
    </message>
    <message>
        <location line="+100"/>
        <source>Range:</source>
        <translation>Interval:</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>to</source>
        <translation>til</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="+193"/>
        <source>Send Coins</source>
        <translation>Send Agetron</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <location filename="../walletview.cpp" line="+42"/>
        <source>&amp;Export</source>
        <translation>Eksporter</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportér den aktuelle visning til en fil</translation>
    </message>
    <message>
        <location line="+193"/>
        <source>Backup Wallet</source>
        <translation>Sikkerhedskopier tegnebog</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Wallet Data (*.dat)</source>
        <translation>Tegnebogsdata (*.dat)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Backup Failed</source>
        <translation>Foretagelse af sikkerhedskopi fejlede</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation>Der opstod en fejl i forbindelse med at gemme tegnebogsdata til det nye sted</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Backup Successful</source>
        <translation>Sikkerhedskopieret problemfri</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The wallet data was successfully saved to the new location.</source>
        <translation>Tegnebogsdata blev problemfrit gemt til det nye sted.</translation>
    </message>
</context>
<context>
    <name>Agetron-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="+94"/>
        <source>Agetron version</source>
        <translation>Agetron-version</translation>
    </message>
    <message>
        <location line="+102"/>
        <source>Usage:</source>
        <translation>Anvendelse:</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>Send command to -server or Agetrond</source>
        <translation>Send kommando til -server eller Agetrond</translation>
    </message>
    <message>
        <location line="-23"/>
        <source>List commands</source>
        <translation>Liste over kommandoer</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>Get help for a command</source>
        <translation>Få hjælp til en kommando</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Options:</source>
        <translation>Indstillinger:</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Specify configuration file (default: Agetron.conf)</source>
        <translation>Angiv konfigurationsfil (standard: Agetron.conf)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Specify pid file (default: Agetrond.pid)</source>
        <translation>Angiv pid-fil (default: Agetrond.pid)</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Specify data directory</source>
        <translation>Angiv datakatalog</translation>
    </message>
    <message>
        <location line="-9"/>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>Angiv databasecachestørrelse i megabytes (standard: 25)</translation>
    </message>
    <message>
        <location line="-28"/>
        <source>Listen for connections on &lt;port&gt; (default: 22017 or testnet: 122017)</source>
        <translation>Lyt til forbindelser på &lt;port&gt; (standard: 22017 eller testnetværk: 122017)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Oprethold højest &lt;n&gt; forbindelser til andre i netværket (standard: 125)</translation>
    </message>
    <message>
        <location line="-48"/>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Forbind til en knude for at modtage adresse, og afbryd</translation>
    </message>
    <message>
        <location line="+82"/>
        <source>Specify your own public address</source>
        <translation>Angiv din egen offentlige adresse</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Grænse for afbrydelse til dårlige forbindelser (standard: 100)</translation>
    </message>
    <message>
        <location line="-134"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Antal sekunder dårlige forbindelser skal vente før reetablering (standard: 86400)</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>Der opstod en fejl ved angivelse af RPC-porten %u til at lytte på IPv4: %s</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 19744 or testnet: 119744)</source>
        <translation>Lyt til JSON-RPC-forbindelser på &lt;port&gt; (standard: 19744 eller testnetværk: 119744)</translation>
    </message>
    <message>
        <location line="+37"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accepter kommandolinje- og JSON-RPC-kommandoer</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Kør i baggrunden som en service, og accepter kommandoer</translation>
    </message>
    <message>
        <location line="+37"/>
        <source>Use the test network</source>
        <translation>Brug testnetværket</translation>
    </message>
    <message>
        <location line="-112"/>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Accepter forbindelser udefra (standard: 1 hvis hverken -proxy eller -connect)</translation>
    </message>
    <message>
        <location line="-80"/>
        <source>%s, you must set a rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=Agetronrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;Agetron Alert&quot; admin@foo.com
</source>
        <translation>%s, du skal angive en RPC-adgangskode i konfigurationsfilen:
%s
Det anbefales, at du bruger nedenstående, tilfældige adgangskode:
rpcuser=Agetronrpc
rpcpassword=%s
(du behøver ikke huske denne adgangskode)
Brugernavnet og adgangskode MÅ IKKE være det samme.
Hvis filen ikke eksisterer, opret den og giv ingen andre end ejeren læserettighed.
Det anbefales også at angive alertnotify, så du påmindes om problemer;
f.eks.: alertnotify=echo %%s | mail -s &quot;Agetron Alert&quot; admin@foo.com
</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation>Der opstod en fejl ved angivelse af RPC-porten %u til at lytte på IPv6, falder tilbage til IPv4: %s</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Tildel til den givne adresse og lyt altid på den. Brug [vært]:port-notation for IPv6</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot obtain a lock on data directory %s. Agetron is probably already running.</source>
        <translation>Kan ikke opnå lås på datakatalog %s. Agetron er sandsynligvis allerede startet.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Fejl: Transaktionen blev afvist. Dette kan ske, hvis nogle af dine Agetron i din tegnebog allerede er brugt, som hvis du brugte en kopi af wallet.dat og dine Agetron er blevet brugt i kopien, men ikke er markeret som brugt her.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation>Fejl: Denne transaktion kræver et transaktionsgebyr på minimum %s pga. dens størrelse, kompleksitet eller anvendelse af nyligt modtagne Agetron!</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Execute command when a relevant alert is received (%s in cmd is replaced by message)</source>
        <translation>Udfør kommando, når en relevant advarsel modtages (%s i kommandoen erstattes med beskeden)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Udfør kommando, når en transaktion i tegnebogen ændres (%s i kommandoen erstattes med TxID)</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: 27000)</source>
        <translation>Angiv maksimumstørrelse for høj prioritet/lavt gebyr-transaktioner i bytes (standard: 27000)</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Dette er en foreløbig testudgivelse - brug på eget ansvar - brug ikke til udvinding eller handelsprogrammer</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Advarsel: -paytxfee er sat meget højt! Dette er det gebyr du vil betale, hvis du sender en transaktion.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: Displayed transactions may not be correct! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Advarsel: Viste transaktioner kan være ukorrekte! Du eller andre knuder kan have behov for at opgradere.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong Agetron will not work properly.</source>
        <translation>Advarsel: Undersøg venligst, at din computers dato og klokkeslæt er korrekt indstillet! Hvis der er fejl i disse, vil Agetron ikke fungere korrekt.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Advarsel: fejl under læsning af wallet.dat! Alle nøgler blev læst korrekt, men transaktionsdata eller adressebogsposter kan mangle eller være forkerte.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Advarsel: wallet.dat ødelagt, data reddet! Oprindelig wallet.net gemt som wallet.{timestamp}.bak i %s; hvis din saldo eller dine transaktioner er forkert, bør du genskabe fra en sikkerhedskopi.</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Forsøg at genskabe private nøgler fra ødelagt wallet.dat</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Block creation options:</source>
        <translation>Blokoprettelsestilvalg:</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Connect only to the specified node(s)</source>
        <translation>Tilslut kun til de(n) angivne knude(r)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Corrupted block database detected</source>
        <translation>Ødelagt blokdatabase opdaget</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Find egen IP-adresse (standard: 1 når lytter og ingen -externalip)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Ønsker du at genbygge blokdatabasen nu?</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error initializing block database</source>
        <translation>Klargøring af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Klargøring af tegnebogsdatabasemiljøet %s mislykkedes!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error loading block database</source>
        <translation>Indlæsning af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error opening block database</source>
        <translation>Åbning af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error: Disk space is low!</source>
        <translation>Fejl: Mangel på ledig diskplads!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>Fejl: Tegnebog låst, kan ikke oprette transaktion!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: system error: </source>
        <translation>Fejl: systemfejl: </translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Lytning på enhver port mislykkedes. Brug -listen=0, hvis du ønsker dette.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to read block info</source>
        <translation>Læsning af blokinformation mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to read block</source>
        <translation>Læsning af blok mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to sync block index</source>
        <translation>Synkronisering af blokindeks mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block index</source>
        <translation>Skrivning af blokindeks mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block info</source>
        <translation>Skrivning af blokinformation mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block</source>
        <translation>Skrivning af blok mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write file info</source>
        <translation>Skriving af filinformation mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write to coin database</source>
        <translation>Skrivning af Agetron-database mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write transaction index</source>
        <translation>Skrivning af transaktionsindeks mislykkedes</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write undo data</source>
        <translation>Skrivning af genskabelsesdata mislykkedes</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Find peers using DNS lookup (default: 1 unless -connect)</source>
        <translation>Find ligeværdige ved DNS-opslag (standard: 1 hvis ikke -connect)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Generate coins (default: 0)</source>
        <translation>Generer Agetron (standard: 0)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>How many blocks to check at startup (default: 288, 0 = all)</source>
        <translation>Antal blokke som tjekkes ved opstart (0=alle, standard: 288)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>How thorough the block verification is (0-4, default: 3)</source>
        <translation>Grundighed af efterprøvning af blokke (0-4, standard: 3)</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Not enough file descriptors available.</source>
        <translation>For få tilgængelige fildeskriptorer.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>Genbyg blokkædeindeks fra nuværende blk000??.dat filer</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Set the number of threads to service RPC calls (default: 4)</source>
        <translation>Angiv antallet af tråde til at håndtere RPC-kald (standard: 4)</translation>
    </message>
    <message>
        <location line="+26"/>
        <source>Verifying blocks...</source>
        <translation>Efterprøver blokke...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Verifying wallet...</source>
        <translation>Efterprøver tegnebog...</translation>
    </message>
    <message>
        <location line="-69"/>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>Importerer blokke fra ekstern blk000??.dat fil</translation>
    </message>
    <message>
        <location line="-76"/>
        <source>Set the number of script verification threads (up to 16, 0 = auto, &lt;0 = leave that many cores free, default: 0)</source>
        <translation>Angiv nummeret af skriptefterprøvningstråde (op til 16, 0 = automatisk, &lt;0 = efterlad det antal kerner tilgængelige, standard: 0)</translation>
    </message>
    <message>
        <location line="+77"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Invalid -tor address: &apos;%s&apos;</source>
        <translation>Ugyldig -tor adresse: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ugyldigt beløb til -minrelaytxfee=&lt;beløb&gt;:&apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ugyldigt beløb til -mintxfee=&lt;beløb&gt;:&apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Maintain a full transaction index (default: 0)</source>
        <translation>Vedligehold et komplet transaktionsindeks (standard: 0)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>Maksimum for modtagelsesbuffer pr. forbindelse, &lt;n&gt;*1000 bytes (standard: 5000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>Maksimum for afsendelsesbuffer pr. forbindelse, &lt;n&gt;*1000 bytes (standard: 1000)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Only accept block chain matching built-in checkpoints (default: 1)</source>
        <translation>Accepter kun blokkæde, som matcher indbyggede kontrolposter (standard: 1)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>Tilslut kun til knuder i netværk &lt;net&gt; (IPv4, IPv6 eller Tor)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Output extra debugging information. Implies all other -debug* options</source>
        <translation>Skriv ekstra fejlsøgningsinformation. Indebærer alle andre -debug* tilvalg</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Output extra network debugging information</source>
        <translation>Skriv ekstra netværksfejlsøgningsinformation</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Prepend debug output with timestamp</source>
        <translation>Tilføj fejlsøgningsoutput med tidsstempel</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>SSL options: (see the Agetron Wiki for SSL setup instructions)</source>
        <translation>SSL-indstillinger: (se Agetron Wiki for SSL-opsætningsinstruktioner)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Select the version of socks proxy to use (4-5, default: 5)</source>
        <translation>Angiv version af SOCKS-proxyen (4-5, standard: 5)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Send sporings-/fejlsøgningsinformation til konsollen i stedet for debug.log filen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Send trace/debug info to debugger</source>
        <translation>Send sporings-/fejlsøgningsinformation til fejlsøgningprogrammet</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Set maximum block size in bytes (default: 250000)</source>
        <translation>Angiv maksimumblokstørrelse i bytes (standard: 250000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>Angiv minimumsblokstørrelse i bytes (standard: 0)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Formindsk debug.log filen ved klientopstart (standard: 1 hvis ikke -debug)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Signing transaction failed</source>
        <translation>Underskrift af transaktion mislykkedes</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>Angiv tilslutningstimeout i millisekunder (standard: 5000)</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>System error: </source>
        <translation>Systemfejl: </translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Transaction amount too small</source>
        <translation>Transaktionsbeløb er for lavt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Transaction amounts must be positive</source>
        <translation>Transaktionsbeløb skal være positive</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Transaction too large</source>
        <translation>Transaktionen er for stor</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>Forsøg at bruge UPnP til at konfigurere den lyttende port (standard: 0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Forsøg at bruge UPnP til at konfigurere den lyttende port (standard: 1 når lytter)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use proxy to reach tor hidden services (default: same as -proxy)</source>
        <translation>Brug proxy til at tilgå Tor Hidden Services (standard: som -proxy)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Username for JSON-RPC connections</source>
        <translation>Brugernavn til JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Advarsel: Denne version er forældet, opgradering påkrævet!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>You need to rebuild the database</source>
        <translation>Du skal genbygge databaserne med -reindex for at ændre -txindex</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat ødelagt, redning af data mislykkedes</translation>
    </message>
    <message>
        <location line="-50"/>
        <source>Password for JSON-RPC connections</source>
        <translation>Adgangskode til JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <location line="-67"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Tillad JSON-RPC-forbindelser fra bestemt IP-adresse</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Send kommandoer til knude, der kører på &lt;ip&gt; (standard: 127.0.0.1)</translation>
    </message>
    <message>
        <location line="-120"/>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Udfør kommando, når den bedste blok ændres (%s i kommandoen erstattes med blokhash)</translation>
    </message>
    <message>
        <location line="+147"/>
        <source>Upgrade wallet to latest format</source>
        <translation>Opgrader tegnebog til seneste format</translation>
    </message>
    <message>
        <location line="-21"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Angiv nøglepoolstørrelse til &lt;n&gt; (standard: 100)</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Gennemsøg blokkæden for manglende tegnebogstransaktioner</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>Use OpenSSL (http) for JSON-RPC connections</source>
        <translation>Brug OpenSSL (http) for JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <location line="-26"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Servercertifikat-fil (standard: server.cert)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Server private key (default: server.pem)</source>
        <translation>Serverens private nøgle (standard: server.pem)</translation>
    </message>
    <message>
        <location line="-151"/>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Acceptable ciphers (standard: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <location line="+165"/>
        <source>This help message</source>
        <translation>Denne hjælpebesked</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>Kunne ikke tildele %s på denne computer (bind returnerede fejl %d, %s)</translation>
    </message>
    <message>
        <location line="-91"/>
        <source>Connect through socks proxy</source>
        <translation>Tilslut via SOCKS-proxy</translation>
    </message>
    <message>
        <location line="-10"/>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Tillad DNS-opslag for -addnode, -seednode og -connect</translation>
    </message>
    <message>
        <location line="+55"/>
        <source>Loading addresses...</source>
        <translation>Indlæser adresser...</translation>
    </message>
    <message>
        <location line="-35"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Fejl ved indlæsning af wallet.dat: Tegnebog ødelagt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error loading wallet.dat: Wallet requires newer version of Agetron</source>
        <translation>Fejl ved indlæsning af wallet.dat: Tegnebog kræver en nyere version af Agetron</translation>
    </message>
    <message>
        <location line="+93"/>
        <source>Wallet needed to be rewritten: restart Agetron to complete</source>
        <translation>Det var nødvendigt at genskrive tegnebogen: genstart Agetron for at gennemføre</translation>
    </message>
    <message>
        <location line="-95"/>
        <source>Error loading wallet.dat</source>
        <translation>Fejl ved indlæsning af wallet.dat</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Ugyldig -proxy adresse: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Ukendt netværk anført i -onlynet: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>Ukendt -socks proxy-version: %i</translation>
    </message>
    <message>
        <location line="-96"/>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>Kan ikke finde -bind adressen: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>Kan ikke finde -externalip adressen: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ugyldigt beløb for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid amount</source>
        <translation>Ugyldigt beløb</translation>
    </message>
    <message>
        <location line="-6"/>
        <source>Insufficient funds</source>
        <translation>Manglende dækning</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Loading block index...</source>
        <translation>Indlæser blokindeks...</translation>
    </message>
    <message>
        <location line="-57"/>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Tilføj en knude til at forbinde til og forsøg at holde forbindelsen åben</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>Unable to bind to %s on this computer. Agetron is probably already running.</source>
        <translation>Kunne ikke tildele %s på denne computer. Agetron kører sikkert allerede.</translation>
    </message>
    <message>
        <location line="+64"/>
        <source>Fee per KB to add to transactions you send</source>
        <translation>Gebyr pr. kB, som skal tilføjes til transaktioner, du sender</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Loading wallet...</source>
        <translation>Indlæser tegnebog...</translation>
    </message>
    <message>
        <location line="-52"/>
        <source>Cannot downgrade wallet</source>
        <translation>Kan ikke nedgradere tegnebog</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot write default address</source>
        <translation>Kan ikke skrive standardadresse</translation>
    </message>
    <message>
        <location line="+64"/>
        <source>Rescanning...</source>
        <translation>Genindlæser...</translation>
    </message>
    <message>
        <location line="-57"/>
        <source>Done loading</source>
        <translation>Indlæsning gennemført</translation>
    </message>
    <message>
        <location line="+82"/>
        <source>To use the %s option</source>
        <translation>For at bruge %s mulighed</translation>
    </message>
    <message>
        <location line="-74"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location line="-31"/>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>Du skal angive rpcpassword=&lt;password&gt; i konfigurationsfilen:
%s
Hvis filen ikke eksisterer, opret den og giv ingen andre end ejeren læserettighed.</translation>
    </message>
</context>
</TS>